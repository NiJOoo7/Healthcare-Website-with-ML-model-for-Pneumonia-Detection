# HealtcareSystemWebApp
 
Created a website for the functioning of a Healthcare System. Tensorflow is used for ML model prediction wherein users can input in an X-Ray Chest Image and then model can determine if the person has Pneumonia or not.
